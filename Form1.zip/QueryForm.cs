﻿using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace CarRentalApp
{
    public class QueryForm : Form
    {
        private readonly TextBox query_box = new TextBox();
        private readonly DataGridView grid = new DataGridView();
        private readonly Label status_label = new Label();

        public QueryForm()
        {
            Text = "SQL-запити";
            Size = new Size(1000, 650);
            StartPosition = FormStartPosition.CenterParent;

            Label title = new Label();
            title.Text = "Введіть SQL-запит:";
            title.Dock = DockStyle.Top;
            title.Height = 30;
            title.Padding = new Padding(8);

            query_box.Dock = DockStyle.Top;
            query_box.Multiline = true;
            query_box.Height = 100;
            query_box.ScrollBars = ScrollBars.Vertical;
            query_box.Font = new Font("Consolas", 11);
            query_box.Text = "SELECT * FROM dbo.Cars";

            Button execute_button = new Button();
            execute_button.Text = "Виконати запит";
            execute_button.Dock = DockStyle.Top;
            execute_button.Height = 40;
            execute_button.Click += (sender, e) => ExecuteQuery();

            
            Button select_button = new Button();
            select_button.Text = "Готові вибірки";
            select_button.Dock = DockStyle.Top;
            select_button.Height = 40;
            select_button.Click += (sender, e) => ShowSelectQueries();

            grid.Dock = DockStyle.Fill;
            grid.ReadOnly = true;
            grid.AllowUserToAddRows = false;
            grid.AutoSizeColumnsMode =
                DataGridViewAutoSizeColumnsMode.Fill;

            status_label.Dock = DockStyle.Bottom;
            status_label.Height = 30;
            status_label.Padding = new Padding(8);

            Controls.Add(grid);
            Controls.Add(status_label);
            Controls.Add(select_button);
            Controls.Add(execute_button);
            Controls.Add(query_box);
            Controls.Add(title);
        }

       
        private void ShowSelectQueries()
        {
            ContextMenuStrip menu = new ContextMenuStrip();

            menu.Items.Add(
                "Клієнти з Дніпра",
                null,
                (sender, e) =>
                    ExecuteSelect(
                        @"SELECT * FROM dbo.Clients
                          WHERE Address LIKE N'Дніпро%';"));

            menu.Items.Add(
                "Мінімальна та максимальна ціна",
                null,
                (sender, e) =>
                    ExecuteSelect(
                        @"SELECT MAX(Price) AS MaxPrice,
                                 MIN(Price) AS MinPrice
                          FROM dbo.Cars;"));

            menu.Items.Add(
                "Автомобілі на літеру T",
                null,
                (sender, e) =>
                    ExecuteSelect(
                        @"SELECT * FROM dbo.Cars
                          WHERE Brand LIKE N'T%';"));

            menu.Show(Cursor.Position);
        }

       
        private void ExecuteSelect(string query)
        {
            try
            {
                using (SqlConnection connection =
                    Database.GetConnection())
                using (SqlDataAdapter adapter =
                    new SqlDataAdapter(query, connection))
                {
                    DataTable table = new DataTable();
                    adapter.Fill(table);

                    grid.DataSource = table;

                    status_label.Text =
                        "Вибірку виконано. Кількість рядків: " +
                        table.Rows.Count;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    ex.Message,
                    "Помилка SQL-запиту",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }

        private void ExecuteQuery()
        {
            string sql = query_box.Text.Trim();

            if (!sql.StartsWith(
                "SELECT", StringComparison.OrdinalIgnoreCase))
            {
                MessageBox.Show(
                    "Дозволені лише запити SELECT.");
                return;
            }

            try
            {
                using (SqlConnection connection =
                    Database.GetConnection())
                using (SqlDataAdapter adapter =
                    new SqlDataAdapter(sql, connection))
                {
                    DataTable result = new DataTable();
                    adapter.Fill(result);

                    grid.DataSource = result;

                    status_label.Text =
                        "Запит виконано. Кількість рядків: " +
                        result.Rows.Count;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    ex.Message,
                    "Помилка SQL-запиту",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }
    }
}
